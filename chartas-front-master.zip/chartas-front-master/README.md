First install dependencies:

npm install vis-timeline

npm install vis-network

npm install leaflet